import router from '@/router'
import { RouteRecordRaw } from 'vue-router'

export class trackRoute {
  allRoutes: RouteRecordRaw[] = []
  // 递归处理路由信息，提取每个路径的 对应的
  extractParentRouteNames(routes, parentNames = [], parentPath = '') {
    const result = {};

    routes.forEach(route => {
      if (route.name && route.path) {
        // 1. 生成当前路由的完整路径
        const fullPath = parentPath ? `${parentPath}/${route.path}` : route.path;
  
        // 2. 生成父路由 name 列表，并添加当前路由的 name 到最后
        result[fullPath] = [...parentNames, route.name];
  
        // 3. 如果有子路由，递归处理子路由，传递当前路由的完整路径和 name 作为父路由信息
        if (route.children && route.children.length > 0) {
          const childResults = this.extractParentRouteNames(route.children, result[fullPath], fullPath);
          Object.assign(result, childResults);
        }
      }
    });
  
    return result;
  
  }
  // 函数：将URL切分为n个部分，并去除 `:` 后面的部分 获取当前的路由
  splitUrl(url) {
    // 1. 删除开头和结尾的斜杠
    const cleanUrl = url.replace(/^\/|\/$/g, '')
    let resStr = ''

    // 2. 使用 / 分割成数组
    const parts = cleanUrl.split('/')

    // 3. 去除每个部分中 `:` 及其后面的内容
    const result = parts.map((part) => part.split(':')[0])

    // 4. 确保第一个部分以 `/` 开头（如果它是根路径的一部分）
    result[0] = `/${result[0]}`
    resStr  = result.join('/')

    return resStr
  }
  //
  getModulesByPath(path: string): string[] {
    // 初始化路由
    if (!(this.allRoutes && this.allRoutes.length)) {
      this.allRoutes = router.getRoutes()
    } else {
      return ['']
    }
    
    const res = this.extractParentRouteNames(this.allRoutes)
    const modulePath = this.splitUrl(path)
    console.log(res,res[modulePath],'allroutes')
    return res[modulePath]
  }
}
